"""Module for Respiration data analysis and visualization."""
from biopsykit.signals.rsp.rsp import RspProcessor

__all__ = ["RspProcessor"]
