"""Module for EEG data analysis and visualization."""
from biopsykit.signals.eeg.eeg import EegProcessor

__all__ = ["EegProcessor"]
